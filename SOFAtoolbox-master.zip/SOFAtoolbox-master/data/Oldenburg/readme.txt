Save here the data from the Oldeburg database, http://sirius.physik.uni-oldenburg.de/downloads/hrir/HRIR_database_mat.zip

Note: before downloading that using that data, you must go to http://medi.uni-oldenburg.de/hrir/html/download.html and accept the form. 

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
