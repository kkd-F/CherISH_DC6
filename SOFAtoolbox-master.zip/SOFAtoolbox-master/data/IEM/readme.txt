Save here the directory '\LigetiHall_CubeletToSt450\' with its content, download from the IEM database: https://phaidra.kug.ac.at/view/o:104376

SOFA Toolbox for Matlab and Octave
Michael Mihocic, ARI, OeAW
